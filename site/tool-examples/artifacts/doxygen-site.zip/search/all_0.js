var searchData=
[
  ['market_5fscore_0',['market_score',['../score_8c.html#a804e097b1d880eec00e5f7979938d6cf',1,'score.c']]]
];
